scrInputClear();
state = 1;
var xo = xCursor + 8;
var yo = yCursor + 8;
isMoving = false;
menuSel = 0;
menuSelEnd = 0;
menuItem[0] = o44__Game.MENU_CANCEL;
itemSellValue = 0;
var obj = instance_position(xo, yo, o44__npcGranny);
if (verify(obj))
{
    isMoving = false;
    canInteract = false;
    if (o44__Game.state == o44__Game.STATE_BUILD_MODE)
    {
        state = 2;
        if (obj.isBaby)
        {
            global.solutionState = true;
        }
        var textbox = scrDrawTextBox(obj.str1, obj.str2, obj.str3);
        with (textbox)
        {
            soundText = o44__Game.soundText;
        }
    }
    else
    {
        menuSelEnd = 0;
        o44__Game.substate = 1;
    }
    exit;
}
scrSfx(sfx_navi04, 10);
obj = instance_position(xo, yo, o44_Cave);
if (verify(obj))
{
    var n = 0;
    if (weaponLevel < 3)
    {
        n++;
        if (weaponLevel == 1)
        {
            menuItem[n] = o44__Game.MENU_ATK_UPGRADE_I;
        }
        else if (weaponLevel == 2)
        {
            menuItem[n] = o44__Game.MENU_ATK_UPGRADE_II;
        }
    }
    if (weaponDist < 3)
    {
        n++;
        if (weaponDist == 1)
        {
            menuItem[n] = o44__Game.MENU_DIST_UPGRADE_I;
        }
        else if (weaponDist == 2)
        {
            menuItem[n] = o44__Game.MENU_DIST_UPGRADE_II;
        }
    }
    n++;
    menuItem[n] = o44__Game.MENU_SET_UNDO;
    n++;
    menuItem[n] = o44__Game.MENU_GOTO_UNDO;
    n++;
    menuItem[n] = o44__Game.MENU_EXIT_TO_MAP;
    if (o44__Game.state == 0)
    {
        menuSelEnd = n;
    }
    else
    {
        menuItem[1] = o44__Game.MENU_GOTO_UNDO;
        menuItem[2] = o44__Game.MENU_GIVE_UP;
        menuSelEnd = 2;
    }
    o44__Game.substate = 1;
    exit;
}
obj = instance_position(xo, yo, o44_Jungle);
if (verify(obj))
{
    menuItem[1] = o44__Game.MENU_START_WAVE;
    if (o44__Game.state == 0)
    {
        menuSelEnd = 1;
    }
    o44__Game.substate = 1;
    exit;
}
obj = instance_position(xo, yo, o44__Tower);
if (verify(obj))
{
    if (obj.type == 0)
    {
        menuItem[1] = o44__Game.MENU_BUY_TOWER_SPEAR_I;
        menuItem[2] = o44__Game.MENU_BUY_TOWER_ROCK_I;
        menuItem[3] = o44__Game.MENU_BUY_TOWER_FIRE_I;
        menuItem[4] = o44__Game.MENU_SELL;
        itemSellValue = o44__Game.PRICE_SELL_TOWER_LEVEL_I;
        menuSelEnd = 4;
        o44__Game.substate = 1;
        exit;
    }
    else if (obj.type == 1)
    {
        menuItem[1] = o44__Game.MENU_BUY_TOWER_SPEAR_II;
        menuItem[2] = o44__Game.MENU_BUY_TOWER_BOW;
        menuItem[3] = o44__Game.MENU_SELL;
        itemSellValue = o44__Game.PRICE_SELL_TOWER_LEVEL_II;
        menuSelEnd = 3;
        o44__Game.substate = 1;
        exit;
    }
    else if (obj.type == 2)
    {
        menuItem[1] = o44__Game.MENU_BUY_TOWER_ROCK_II;
        menuItem[2] = o44__Game.MENU_BUY_TOWER_WHEEL;
        menuItem[3] = o44__Game.MENU_SELL;
        itemSellValue = o44__Game.PRICE_SELL_TOWER_LEVEL_II;
        menuSelEnd = 3;
        o44__Game.substate = 1;
        exit;
    }
    else if (obj.type == 3)
    {
        menuItem[1] = o44__Game.MENU_BUY_TOWER_FIRE_II;
        menuItem[2] = o44__Game.MENU_BUY_TOWER_TAR;
        menuItem[3] = o44__Game.MENU_SELL;
        itemSellValue = o44__Game.PRICE_SELL_TOWER_LEVEL_II;
        menuSelEnd = 3;
        o44__Game.substate = 1;
        exit;
    }
    else
    {
        menuItem[1] = o44__Game.MENU_SELL;
        itemSellValue = o44__Game.PRICE_SELL_TOWER_LEVEL_III;
        menuSelEnd = 1;
        o44__Game.substate = 1;
        exit;
    }
}
obj = instance_position(xo, yo, o44__Food);
if (verify(obj))
{
    menuItem[1] = o44__Game.MENU_SELL;
    if (obj.cooked < 2)
    {
        itemSellValue = o44__Game.PRICE_SELL_FOOD_RAW;
    }
    else
    {
        itemSellValue = o44__Game.PRICE_SELL_FOOD_COOKED;
    }
    menuSelEnd = 1;
    o44__Game.substate = 1;
    exit;
}
obj = instance_position(xo, yo, o44_Bush);
if (verify(obj))
{
    menuItem[1] = o44__Game.MENU_DIG_BUSH;
    menuSelEnd = 1;
    o44__Game.substate = 1;
    exit;
}
obj = instance_position(xo, yo, o44_Boulder);
if (verify(obj))
{
    menuItem[1] = o44__Game.MENU_DIG_BOULDER;
    menuSelEnd = 1;
    o44__Game.substate = 1;
    exit;
}
obj = instance_position(xo, yo, o44__Fire);
if (verify(obj))
{
    menuItem[1] = o44__Game.MENU_DIG_FIRE;
    menuSelEnd = 1;
    o44__Game.substate = 1;
    exit;
}
if (place_meeting(xo, yo, o44_Rocks) || place_meeting(xo, yo, o44_Path) || place_meeting(xo, yo, obj_floor))
{
    if (o44__Game.state == 0)
    {
        menuItem[1] = o44__Game.MENU_START_WAVE;
        menuItem[2] = o44__Game.MENU_SET_UNDO;
        menuItem[3] = o44__Game.MENU_GOTO_UNDO;
        menuItem[4] = o44__Game.MENU_EXIT_TO_MAP;
        menuSelEnd = 4;
    }
    else if (o44__Game.postWave == -1)
    {
        menuItem[1] = o44__Game.MENU_GOTO_UNDO;
        menuItem[2] = o44__Game.MENU_GIVE_UP;
        menuSelEnd = 2;
    }
    else
    {
        menuItem[1] = o44__Game.MENU_GIVE_UP;
        menuSelEnd = 1;
    }
    o44__Game.substate = 1;
    exit;
}
else
{
    menuItem[1] = o44__Game.MENU_BUY_TOWER_DEFAULT;
    menuItem[2] = o44__Game.MENU_BUY_CHICKEN;
    menuItem[3] = o44__Game.MENU_BUY_CAMPFIRE;
    menuSelEnd = 3;
    o44__Game.substate = 1;
    exit;
}
