depth = -999;
STATE_INTRO = -5;
STATE_GAME_START = -4;
STATE_TRANSITION_BACK_TO_MAP = -3;
STATE_TRANSITION_START_NEW_LEVEL = -2;
STATE_OVERWORLD_MAP = -1;
STATE_BUILD_MODE = 0;
STATE_ATTACK_MODE = 1;
STATE_ENDING = 100;
SUBSTATE_GAME_OVER = -1;
SUBSTATE_NORMAL = 0;
SUBSTATE_SELECTION_MENU = 1;
SUBSTATE_YOU_WIN = 100;
scrRandomize(50);
numLevels = 13;
scrLoadGame();
if (!saveStatus)
{
    scrResetSpeedRun();
}
if (global.g44_intro && !saveStatus)
{
    global.g44_intro = false;
    state = STATE_INTRO;
}
else
{
    with (oGame)
    {
        fadeOut = true;
    }
    state = STATE_GAME_START;
}
substate = 0;
currLevel = -1;
wave = 1;
numWaves = 10;
group = 0;
groupsTotal = 0;
preWave = -1;
postWave = -1;
finalWave = false;
dispWave = false;
dispWaveLength = 150;
alarm[0] = -1;
tStartBuffer = 0;
tCantAfford = 0;
for (var i = 0; i < 7; i++)
{
    dinoType[i] = 0;
}
instance_create(x, y, o44_Shadows);
debugDispOn = false;
godModeOn = false;
undostate = false;
undo_map = ds_map_create();
hpMax = 30;
hp = hpMax;
meatStart = 30;
meat = meatStart;
meatDisp = meat;
activeCave = -4;
areaX = 1920;
areaY = 0;
screenWidth = 384;
screenHeight = 216;
areaWidth = screenWidth;
areaHeight = screenHeight;
level[0] = 2;
levelDamage[0] = 0;
level[11] = 2;
levelDamage[11] = 0;
level[12] = 2;
levelDamage[12] = 0;
with (o44_MapNode)
{
    if (level < 11)
    {
        winState = o44__Game.level[level];
    }
}
levelString[0] = scrString("level_name_0");
levelString[1] = scrString("level_name_1");
levelString[2] = scrString("level_name_2");
levelString[3] = scrString("level_name_3");
levelString[4] = scrString("level_name_4");
levelString[5] = scrString("level_name_5");
levelString[6] = scrString("level_name_6");
levelString[7] = scrString("level_name_7");
levelString[8] = scrString("level_name_8");
levelString[9] = scrString("level_name_9");
levelString[10] = scrString("level_name_10");
levelString[11] = scrString("level_name_11");
levelString[12] = scrString("level_name_12");
__view_set(UnknownEnum.Value_0, 0, 0);
__view_set(UnknownEnum.Value_1, 0, 896);
scr44_SetupEntities(-1, -1, -4);
var n = 0;
MENU_CANCEL = n;
n++;
MENU_START_WAVE = n;
n++;
MENU_BUY_TOWER_DEFAULT = n;
n++;
MENU_BUY_TOWER_SPEAR_I = n;
n++;
MENU_BUY_TOWER_SPEAR_II = n;
n++;
MENU_BUY_TOWER_ROCK_I = n;
n++;
MENU_BUY_TOWER_ROCK_II = n;
n++;
MENU_BUY_TOWER_FIRE_I = n;
n++;
MENU_BUY_TOWER_FIRE_II = n;
n++;
MENU_BUY_TOWER_BOW = n;
n++;
MENU_BUY_TOWER_WHEEL = n;
n++;
MENU_BUY_TOWER_TAR = n;
n++;
MENU_BUY_CHICKEN = n;
n++;
MENU_BUY_CAMPFIRE = n;
n++;
MENU_SELL = n;
n++;
MENU_DIG_BUSH = n;
n++;
MENU_DIG_BOULDER = n;
n++;
MENU_DIG_FIRE = n;
n++;
MENU_ATK_UPGRADE_I = n;
n++;
MENU_ATK_UPGRADE_II = n;
n++;
MENU_DIST_UPGRADE_I = n;
n++;
MENU_DIST_UPGRADE_II = n;
n++;
MENU_EXIT_TO_MAP = n;
n++;
MENU_GIVE_UP = n;
n++;
MENU_SET_UNDO = n;
n++;
MENU_GOTO_UNDO = n;
n++;
menuTxt[MENU_CANCEL] = scrString("cancel_text");
menuVal[MENU_CANCEL] = 0;
menuImg[MENU_CANCEL] = 0;
menuTxt[MENU_START_WAVE] = scrString("start_wave_text");
menuVal[MENU_START_WAVE] = 0;
menuImg[MENU_START_WAVE] = 1;
menuTxt[MENU_BUY_TOWER_DEFAULT] = scrString("caveman_text");
menuVal[MENU_BUY_TOWER_DEFAULT] = PRICE_BUY_TOWER_LEVEL_I;
menuImg[MENU_BUY_TOWER_DEFAULT] = 11;
menuTxt[MENU_BUY_CHICKEN] = scrString("chicken_text");
menuVal[MENU_BUY_CHICKEN] = PRICE_BUY_TOWER_LEVEL_I;
menuImg[MENU_BUY_CHICKEN] = 9;
menuTxt[MENU_BUY_CAMPFIRE] = scrString("campfire_text");
menuVal[MENU_BUY_CAMPFIRE] = PRICE_BUY_TOWER_LEVEL_I;
menuImg[MENU_BUY_CAMPFIRE] = 10;
menuTxt[MENU_BUY_TOWER_SPEAR_I] = scrString("spear_text");
menuVal[MENU_BUY_TOWER_SPEAR_I] = PRICE_BUY_TOWER_LEVEL_II;
menuImg[MENU_BUY_TOWER_SPEAR_I] = 12;
menuTxt[MENU_BUY_TOWER_ROCK_I] = scrString("rock_text");
menuVal[MENU_BUY_TOWER_ROCK_I] = PRICE_BUY_TOWER_LEVEL_II;
menuImg[MENU_BUY_TOWER_ROCK_I] = 13;
menuTxt[MENU_BUY_TOWER_FIRE_I] = scrString("fire_text");
menuVal[MENU_BUY_TOWER_FIRE_I] = PRICE_BUY_TOWER_LEVEL_II;
menuImg[MENU_BUY_TOWER_FIRE_I] = 14;
menuTxt[MENU_BUY_TOWER_SPEAR_II] = scrString("spear_2_text");
menuVal[MENU_BUY_TOWER_SPEAR_II] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_SPEAR_II] = 15;
menuTxt[MENU_BUY_TOWER_BOW] = scrString("bow_text");
menuVal[MENU_BUY_TOWER_BOW] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_BOW] = 16;
menuTxt[MENU_BUY_TOWER_ROCK_II] = scrString("rock_2_text");
menuVal[MENU_BUY_TOWER_ROCK_II] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_ROCK_II] = 17;
menuTxt[MENU_BUY_TOWER_WHEEL] = scrString("wheel_text");
menuVal[MENU_BUY_TOWER_WHEEL] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_WHEEL] = 18;
menuTxt[MENU_BUY_TOWER_FIRE_II] = scrString("fire_2_text");
menuVal[MENU_BUY_TOWER_FIRE_II] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_FIRE_II] = 19;
menuTxt[MENU_BUY_TOWER_TAR] = scrString("tar_text");
menuVal[MENU_BUY_TOWER_TAR] = PRICE_BUY_TOWER_LEVEL_III;
menuImg[MENU_BUY_TOWER_TAR] = 20;
menuTxt[MENU_SELL] = scrString("sell_text");
menuVal[MENU_SELL] = 0;
menuImg[MENU_SELL] = 2;
menuTxt[MENU_DIG_BUSH] = scrString("dig_text");
menuVal[MENU_DIG_BUSH] = PRICE_DIG_BUSH;
menuImg[MENU_DIG_BUSH] = 3;
menuTxt[MENU_DIG_BOULDER] = scrString("dig_text");
menuVal[MENU_DIG_BOULDER] = PRICE_DIG_BOULDER;
menuImg[MENU_DIG_BOULDER] = 3;
menuTxt[MENU_DIG_FIRE] = scrString("dig_text");
menuVal[MENU_DIG_FIRE] = PRICE_DIG_FIRE;
menuImg[MENU_DIG_FIRE] = 3;
menuTxt[MENU_ATK_UPGRADE_I] = scrString("weapon_text");
menuVal[MENU_ATK_UPGRADE_I] = PRICE_UPGRADE_ATK_I;
menuImg[MENU_ATK_UPGRADE_I] = 4;
menuTxt[MENU_ATK_UPGRADE_II] = scrString("weapon_text");
menuVal[MENU_ATK_UPGRADE_II] = PRICE_UPGRADE_ATK_II;
menuImg[MENU_ATK_UPGRADE_II] = 5;
menuTxt[MENU_DIST_UPGRADE_I] = scrString("distance_text");
menuVal[MENU_DIST_UPGRADE_I] = PRICE_UPGRADE_DIST_I;
menuImg[MENU_DIST_UPGRADE_I] = 6;
menuTxt[MENU_DIST_UPGRADE_II] = scrString("distance_text");
menuVal[MENU_DIST_UPGRADE_II] = PRICE_UPGRADE_DIST_II;
menuImg[MENU_DIST_UPGRADE_II] = 7;
menuTxt[MENU_EXIT_TO_MAP] = scrString("exit_text");
menuVal[MENU_EXIT_TO_MAP] = 0;
menuImg[MENU_EXIT_TO_MAP] = 8;
menuTxt[MENU_GIVE_UP] = scrString("giveup_text");
menuVal[MENU_GIVE_UP] = 0;
menuImg[MENU_GIVE_UP] = 21;
menuTxt[MENU_SET_UNDO] = "SAVE PT";
menuVal[MENU_SET_UNDO] = 0;
menuImg[MENU_SET_UNDO] = 22;
menuTxt[MENU_GOTO_UNDO] = "LOAD SAVE PT";
menuVal[MENU_GOTO_UNDO] = 0;
menuImg[MENU_GOTO_UNDO] = 23;
totalCavemen = 0;
totalChickens = 0;
upgradeSpending = 0;
scr44_AttractMode();
if (global.cheatID == 1)
{
    with (o44_MapNode)
    {
        winState = 1;
    }
    state = -4;
    substate = 0;
    with (oGame)
    {
        fadeOut = true;
    }
}
soundStep[0] = sfx_step01a;
soundStep[1] = sfx_step01b;
soundStep[2] = sfx_step01c;
soundStep[3] = sfx_step01d;
soundExplode[0] = sfx_explosion07a;
soundExplode[1] = sfx_explosion07b;
soundExplode[2] = sfx_explosion07c;
soundExplode[3] = sfx_explosion07d;
soundExplode[4] = sfx_explosion07e;
soundExplode[5] = sfx_explosion07f;
soundText = sfx_text_loop00c;
soundTextNavi = sfx_navi01;
levelBGM[0] = bgm44_village;
levelBGM[1] = -4;
levelBGM[2] = -4;
levelBGM[3] = -4;
levelBGM[4] = -4;
levelBGM[5] = -4;
levelBGM[6] = -4;
levelBGM[7] = -4;
levelBGM[8] = -4;
levelBGM[9] = -4;
levelBGM[10] = bgm44_volcano;
levelBGM[11] = bgm44_village;
levelBGM[12] = bgm44_village;

enum UnknownEnum
{
    Value_0,
    Value_1
}
