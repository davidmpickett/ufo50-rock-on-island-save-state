if (array_length_1d(my_data) > 0)
{
    x = my_data[0];
    y = my_data[1];
    cooked = my_data[2];
}
