my_data[0] = x;
my_data[1] = y;
my_data[2] = visible;
