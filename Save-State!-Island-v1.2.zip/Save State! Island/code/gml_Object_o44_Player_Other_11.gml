var soundTrig = 0;
if (tCursorBlink++ >= 48)
{
    tCursorBlink = 0;
}
var menuSelPrev = menuSel;
if (pressLeft)
{
    menuSel--;
    if (menuSel < 0)
    {
        menuSel = menuSelEnd;
    }
}
else if (pressRight)
{
    menuSel++;
    if (menuSel > menuSelEnd)
    {
        menuSel = 0;
    }
}
if (menuSel != menuSelPrev)
{
    soundTrig = 1;
}
var menuClose = false;
if (fire1pressed)
{
    soundTrig = 2;
    menuClose = true;
}
else if (fire2pressed)
{
    var currOption = menuItem[menuSel];
    var currVal = o44__Game.menuVal[currOption];
    var fireCheck = false;
    if (currOption == o44__Game.MENU_CANCEL)
    {
        soundTrig = 2;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_START_WAVE)
    {
        muteBGM();
        soundTrig = 9;
        o44__Game.preWave = 0;
        o44__Game.state = 1;
        fireCheck = true;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_SELL)
    {
        var obj = instance_position(xCursor + 8, yCursor + 8, o44__Tower);
        if (!obj)
        {
            obj = instance_position(xCursor + 8, yCursor + 8, o44__Food);
        }
        for (var i = 0; i < 3; i++)
        {
            var fx = scrFX(sFX_StarRotate, 1/3, obj.x + 8 + scrIRandomRange(-8, 8), obj.y + 8 + scrIRandomRange(-16, 8));
            fx.direction = 90;
            fx.speed = 0.2;
            fx.depth = -100;
        }
        with (obj)
        {
            instance_destroy();
        }
        o44__Game.meat += itemSellValue;
        o44__Game.meat = min(o44__Game.meat, 99);
        soundTrig = 5;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_ATK_UPGRADE_I || currOption == o44__Game.MENU_ATK_UPGRADE_II)
    {
        if (o44__Game.meat >= currVal)
        {
            weaponLevel++;
            o44__Game.meat -= currVal;
            scrTextPopup(x, y - 8, scrString("attack_plus_text"), 60);
            soundTrig = 8;
            menuClose = true;
            if (o44__Game.currLevel != 0)
            {
                o44__Game.upgradeSpending += currVal;
            }
            o44__Game.mostUpgradeSpending = max(o44__Game.upgradeSpending, o44__Game.mostUpgradeSpending);
        }
        else
        {
            o44__Game.tCantAfford = 20;
            soundTrig = 3;
        }
    }
    else if (currOption == o44__Game.MENU_DIST_UPGRADE_I || currOption == o44__Game.MENU_DIST_UPGRADE_II)
    {
        if (o44__Game.meat >= currVal)
        {
            weaponDist++;
            o44__Game.meat -= currVal;
            scrTextPopup(x, y - 8, scrString("distance_plus_text"), 60);
            soundTrig = 8;
            menuClose = true;
            if (o44__Game.currLevel != 0)
            {
                o44__Game.upgradeSpending += currVal;
            }
            o44__Game.mostUpgradeSpending = max(o44__Game.upgradeSpending, o44__Game.mostUpgradeSpending);
        }
        else
        {
            o44__Game.tCantAfford = 20;
            soundTrig = 3;
        }
    }
    else if (currOption == o44__Game.MENU_EXIT_TO_MAP || currOption == o44__Game.MENU_GIVE_UP)
    {
        scrDrawTextBox(scrString("exit_confirm_text"), "", "");
        with (oTextBox)
        {
            soundText = o44__Game.soundText;
            soundNavi = o44__Game.soundTextNavi;
            yesNo = true;
            height = 32;
        }
        oTextBox.callerID = id;
        yesNoWaiting = true;
        canInteract = false;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_GIVE_UP)
    {
        scrBGM(bgm44_stingLose, false);
        with (o44__Game)
        {
            hp = 0;
            substate = -1;
            alarm[10] = dispWaveLength;
            alarm[11] = -1;
        }
        state = 0;
        alarm[11] = -1;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_GOTO_UNDO)
    {
        if (o44__Game.undostate == false)
        {
            scrTextPopup(x, y - 8, "NO SAVE POINT", 60);
            soundTrig = 3;
        }
        else if (o44__Game.postWave >= 0)
        {
            scrTextPopup(x, y - 8, "CAN'T LOAD NOW", 60);
            soundTrig = 3;
        }
        else
        {
            o44__Game.state = 0;
            o44__Game.substate = 0;
            muteBGM();
            with (o44__pShot)
            {
                instance_destroy();
            }
            with (o44__Enemy)
            {
                instance_destroy();
            }
            with (o44__Tower)
            {
                instance_destroy();
            }
            with (o44__Fire)
            {
                instance_destroy();
            }
            with (o44__Food)
            {
                instance_destroy();
            }
            with (o44_Bush)
            {
                instance_destroy();
            }
            with (o44_Boulder)
            {
                instance_destroy();
            }
            tower_arr = 0;
            fire_arr = 0;
            food_arr = 0;
            bush_arr = 0;
            boulder_arr = 0;
            o44__Game.group = 0;
            o44__Game.groupsTotal = 0;
            tower_arr = o44__Game.undo_map[0];
            fire_arr = o44__Game.undo_map[1];
            food_arr = o44__Game.undo_map[2];
            weaponLevel = o44__Game.undo_map[3];
            weaponDist = o44__Game.undo_map[4];
            o44__Game.wave = o44__Game.undo_map[5];
            o44__Game.meat = o44__Game.undo_map[6];
            o44__Game.hp = o44__Game.undo_map[7];
            x = o44__Game.undo_map[8];
            y = o44__Game.undo_map[9];
            bush_arr = o44__Game.undo_map[10];
            boulder_arr = o44__Game.undo_map[11];
            o44__Game.upgradeSpending = o44__Game.undo_map[12];
            _dir = 0;
            isMoving = false;
            _move = false;
            xx = x;
            yy = y;
            xFace = 1;
            tMoveAlign = 0;
            tMoveDiagonal = 0;
            invincibility = 0;
            with (o44_Jungle)
            {
                if (active)
                {
                    scr44_SetWave(num);
                }
            }
            var object_data = 0;
            for (var i = 0; i < array_height_2d(tower_arr); i += 1)
            {
                object_data = tower_arr[i][0];
                inst = instance_create(0, 0, o44__Tower);
                inst.my_data = object_data;
                with (inst)
                {
                    event_user(0);
                }
            }
            object_data = 0;
            for (var i = 0; i < array_height_2d(fire_arr); i += 1)
            {
                object_data = fire_arr[i][0];
                inst = instance_create(0, 0, o44__Fire);
                inst.my_data = object_data;
                with (inst)
                {
                    event_user(0);
                }
            }
            object_data = 0;
            for (var i = 0; i < array_height_2d(food_arr); i += 1)
            {
                object_data = food_arr[i][0];
                inst = instance_create(0, 0, o44__Food);
                inst.my_data = object_data;
                with (inst)
                {
                    event_user(0);
                }
            }
            object_data = 0;
            for (var i = 0; i < array_height_2d(bush_arr); i += 1)
            {
                object_data = bush_arr[i][0];
                inst = instance_create(0, 0, o44_Bush);
                inst.my_data = object_data;
                with (inst)
                {
                    event_user(0);
                }
            }
            object_data = 0;
            for (var i = 0; i < array_height_2d(boulder_arr); i += 1)
            {
                object_data = boulder_arr[i][0];
                inst = instance_create(0, 0, o44_Boulder);
                inst.my_data = object_data;
                with (inst)
                {
                    event_user(0);
                }
            }
            tower_arr = 0;
            fire_arr = 0;
            food_arr = 0;
            bush_arr = 0;
            boulder_arr = 0;
            scrTextPopup(x, y - 8, "SAVE POINT LOADED", 60);
            soundTrig = 8;
        }
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_SET_UNDO)
    {
        tower_arr = 0;
        fire_arr = 0;
        food_arr = 0;
        bush_arr = 0;
        boulder_arr = 0;
        arr_index = 0;
        with (o44__Tower)
        {
            event_user(2);
            other.tower_arr[other.arr_index][0] = my_data;
            other.arr_index += 1;
        }
        arr_index = 0;
        with (o44__Fire)
        {
            event_user(2);
            other.fire_arr[other.arr_index][0] = my_data;
            other.arr_index += 1;
        }
        arr_index = 0;
        with (o44__Food)
        {
            event_user(2);
            other.food_arr[other.arr_index][0] = my_data;
            other.arr_index += 1;
        }
        arr_index = 0;
        with (o44_Bush)
        {
            event_user(2);
            other.bush_arr[other.arr_index][0] = my_data;
            other.arr_index += 1;
        }
        arr_index = 0;
        with (o44_Boulder)
        {
            event_user(2);
            other.boulder_arr[other.arr_index][0] = my_data;
            other.arr_index += 1;
        }
        o44__Game.undo_map[0] = tower_arr;
        o44__Game.undo_map[1] = fire_arr;
        o44__Game.undo_map[2] = food_arr;
        o44__Game.undo_map[3] = weaponLevel;
        o44__Game.undo_map[4] = weaponDist;
        o44__Game.undo_map[5] = o44__Game.wave;
        o44__Game.undo_map[6] = o44__Game.meat;
        o44__Game.undo_map[7] = o44__Game.hp;
        o44__Game.undo_map[8] = x;
        o44__Game.undo_map[9] = y;
        o44__Game.undo_map[10] = bush_arr;
        o44__Game.undo_map[11] = boulder_arr;
        o44__Game.undo_map[12] = o44__Game.upgradeSpending;
        tower_arr = 0;
        fire_arr = 0;
        food_arr = 0;
        bush_arr = 0;
        boulder_arr = 0;
        o44__Game.undostate = true;
        scrTextPopup(x, y - 8, "SAVE POINT SET", 60);
        soundTrig = 8;
        menuClose = true;
    }
    else if (currOption == o44__Game.MENU_DIG_BUSH || currOption == o44__Game.MENU_DIG_BOULDER || currOption == o44__Game.MENU_DIG_FIRE)
    {
        if (o44__Game.meat >= currVal)
        {
            var target;
            if (currOption == o44__Game.MENU_DIG_BUSH)
            {
                target = o44_Bush;
            }
            if (currOption == o44__Game.MENU_DIG_BOULDER)
            {
                target = o44_Boulder;
            }
            if (currOption == o44__Game.MENU_DIG_FIRE)
            {
                target = o44__Fire;
            }
            var obj = instance_place(xCursor + 8, yCursor + 8, target);
            var fx = scrFX(sFX_CloudPuff, 0.25, obj.x + 8, obj.y + 8);
            fx.depth = -100;
            with (obj)
            {
                instance_destroy();
            }
            o44__Game.meat -= currVal;
            soundTrig = 6;
            menuClose = true;
        }
        else
        {
            o44__Game.tCantAfford = 20;
            soundTrig = 3;
        }
    }
    else if (currOption == o44__Game.MENU_BUY_TOWER_DEFAULT || currOption == o44__Game.MENU_BUY_CHICKEN || currOption == o44__Game.MENU_BUY_CAMPFIRE)
    {
        if (o44__Game.meat >= currVal)
        {
            var target;
            if (currOption == o44__Game.MENU_BUY_TOWER_DEFAULT)
            {
                target = o44__Tower;
            }
            if (currOption == o44__Game.MENU_BUY_CHICKEN)
            {
                target = o44__Food;
            }
            if (currOption == o44__Game.MENU_BUY_CAMPFIRE)
            {
                target = o44__Fire;
            }
            instance_create(xCursor, yCursor, target);
            o44__Game.meat -= currVal;
            soundTrig = 4;
            menuClose = true;
            if (o44__Game.currLevel != 0)
            {
                o44__Game.totalChickens = instance_number(o44__Food);
            }
            o44__Game.mostChickens = max(o44__Game.totalChickens, o44__Game.mostChickens);
        }
        else
        {
            o44__Game.tCantAfford = 20;
            soundTrig = 3;
        }
    }
    else if (currOption == o44__Game.MENU_BUY_TOWER_SPEAR_I || currOption == o44__Game.MENU_BUY_TOWER_SPEAR_II || currOption == o44__Game.MENU_BUY_TOWER_BOW || currOption == o44__Game.MENU_BUY_TOWER_ROCK_I || currOption == o44__Game.MENU_BUY_TOWER_ROCK_II || currOption == o44__Game.MENU_BUY_TOWER_WHEEL || currOption == o44__Game.MENU_BUY_TOWER_FIRE_I || currOption == o44__Game.MENU_BUY_TOWER_FIRE_II || currOption == o44__Game.MENU_BUY_TOWER_TAR)
    {
        if (o44__Game.meat >= currVal)
        {
            var obj = instance_place(xCursor + 8, yCursor + 8, o44__Tower);
            if (verify(obj))
            {
                obj.tUpgradeFx = 20;
                if (currOption == o44__Game.MENU_BUY_TOWER_SPEAR_I)
                {
                    obj.type = 1;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_ROCK_I)
                {
                    obj.type = 2;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_FIRE_I)
                {
                    obj.type = 3;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_SPEAR_II)
                {
                    obj.type = 4;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_BOW)
                {
                    obj.type = 5;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_ROCK_II)
                {
                    obj.type = 6;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_WHEEL)
                {
                    obj.type = 7;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_FIRE_II)
                {
                    obj.type = 8;
                }
                else if (currOption == o44__Game.MENU_BUY_TOWER_TAR)
                {
                    obj.type = 9;
                }
            }
            o44__Game.meat -= currVal;
            soundTrig = 7;
            menuClose = true;
            if (o44__Game.currLevel != 0)
            {
                o44__Game.totalCavemen = instance_number(o44__Tower);
            }
            o44__Game.mostCavemen = max(o44__Game.totalCavemen, o44__Game.mostCavemen);
            if (o44__Game.currLevel != 0 && obj.type >= 4)
            {
                o44__Game.upgradeSpending += currVal;
            }
            o44__Game.mostUpgradeSpending = max(o44__Game.upgradeSpending, o44__Game.mostUpgradeSpending);
        }
        else
        {
            o44__Game.tCantAfford = 20;
            soundTrig = 3;
        }
    }
    if (fireCheck)
    {
        with (o44__Tower)
        {
            fireBuff = 0;
        }
        with (o44__Fire)
        {
            for (var i = 0; i < 4; i++)
            {
                var xt = x + 8 + lengthdir_x(16, 90 * i);
                var yt = y + 8 + lengthdir_y(16, 90 * i);
                var obj = instance_position(xt, yt, o44__Tower);
                if (verify(obj))
                {
                    obj.fireBuff += 1;
                }
            }
        }
    }
}
if (soundTrig)
{
    if (soundTrig == 1)
    {
        scrSfx(sfx_navi09, 20);
    }
    else if (soundTrig == 2)
    {
        scrSfx(sfx_deselect02, 30);
    }
    else if (soundTrig == 3)
    {
        scrSfx(sfx_nope03, 30);
    }
    else if (soundTrig == 4)
    {
        scrSfx(sfx_boost01c, 30);
    }
    else if (soundTrig == 5)
    {
        scrSfx(sfx_money_loop00, 30);
    }
    else if (soundTrig == 6)
    {
        scrSfx(sfx_flap00, 30);
    }
    else if (soundTrig == 7)
    {
        scrSfx(sfx_powerup03, 30);
    }
    else if (soundTrig == 8)
    {
        scrSfx(sfx_powerup00, 30);
    }
    else if (soundTrig == 9)
    {
        scrSfx(sfx_polyAlert01, 60);
    }
}
if (menuClose)
{
    state = 0;
    canInteract = false;
    tCanInteractBuffer = 0;
    o44__Game.substate = 0;
}
